package com.training.services;
import model.Student;

import java.io.*;
public class StudentService {

    public boolean writeToFile(File file, Student obj) throws IOException{
        boolean result = false;
        try(PrintWriter writer =
                    new PrintWriter(
                            new FileWriter(file,true));)
        {

            writer.println(obj);

            result = true;

        }catch(Exception e) {
            throw e;
        }
        return result;

    }

    public Student readFromFile(File file){

        return null;
    }

    public boolean serialize(File file , Student obj) {

        boolean result =false;
        try(ObjectOutputStream outStream= new ObjectOutputStream(new FileOutputStream(file))){

            outStream.writeObject(obj);

            result =true;
        }catch (IOException e){
            e.printStackTrace();
        }

        return result;
    }

    public Object deSerialize(File file) {

        Object obj =null;

        try(ObjectInputStream inStream =
                    new ObjectInputStream(new FileInputStream(file))){

            obj = inStream.readObject();
        }catch(IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }

        return obj;

    }
}
