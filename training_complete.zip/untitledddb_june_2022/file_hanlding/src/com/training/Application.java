package com.training;

import com.training.services.StudentService;
import model.Student;
import java.io.*;
public class Application {

    public static void main(String[] args) {

        StudentService service = new StudentService();


        Student ram = new Student(101,"Ramesh",78);

        boolean result = false;
        boolean streamResult=false;
        try {
            result = service.writeToFile(new File("e:\\temp","Mystudents.txt"),ram);
            // streamResult = service.serialize(new File("student.ser"),ram);

            System.out.println(service.deSerialize(new File("student.ser")));
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Is Data Added to file "+ result);

        System.out.println("Is Data Added to file "+ streamResult);


    }
}
