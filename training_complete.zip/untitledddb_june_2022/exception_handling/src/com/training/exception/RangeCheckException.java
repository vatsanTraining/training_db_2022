package com.training.exception;

public class RangeCheckException extends  Exception{

}
