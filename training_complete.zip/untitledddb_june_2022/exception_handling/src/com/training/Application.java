package com.training;

public class Application {
}
