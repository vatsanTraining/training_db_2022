package com.training;

public class UsePrintString implements Runnable{


    private String string1;
    private String string2;

    public UsePrintString(String string1, String string2) {
        this.string1 = string1;
        this.string2 = string2;

        Thread t = new Thread(this);
         t.start();
    }

    @Override
    public void run() {

        PrintString.print(string1,string2);
    }
}
