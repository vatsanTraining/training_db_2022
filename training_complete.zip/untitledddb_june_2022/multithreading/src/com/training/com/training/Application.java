package com.training.com.training;

import com.training.UsePrintString;

public class Application {

    public static void main(String[] args) {

        new UsePrintString("coke","pizza");
        new UsePrintString("idly","sambhar");
        new UsePrintString("tea","biscuit");
        new UsePrintString("parrata","dahi");

    }
}
