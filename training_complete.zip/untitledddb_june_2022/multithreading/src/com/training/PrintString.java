package com.training;

public class PrintString {



    public synchronized static void print(String str1,String str2){

        System.out.println(str1);

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.out.println(str2);

    }
}
