
/*
package
import
class
 */
package com.training;

public class Greeting {

    public String getMessage(){

        return "Welcome to Java Programming";
    }

}
