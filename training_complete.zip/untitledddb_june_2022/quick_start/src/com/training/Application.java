package com.training;

public class Application {

    public static void main(String[] args) {

        Greeting grtObj = new Greeting();

        System.out.println(grtObj.getMessage());

    }
}
