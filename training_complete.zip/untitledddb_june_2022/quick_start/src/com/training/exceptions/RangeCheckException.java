package com.training.exceptions;

public class RangeCheckException extends Exception{

    private String errorCode;
    private String errorMessage;

    public RangeCheckException(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    @Override
    public String getMessage() {
        return this.errorCode + ","+this.errorMessage;
    }

}
