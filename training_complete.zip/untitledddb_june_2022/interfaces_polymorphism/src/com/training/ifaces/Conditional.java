package com.training.ifaces;

public interface Conditional {

     boolean test();
}
