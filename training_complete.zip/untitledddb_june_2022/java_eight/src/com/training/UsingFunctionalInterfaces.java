package com.training;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.*;
class MyExample implements  Runnable{

    @Override
    public void run() {
        for(int i=1;i<=5;i++){
            System.out.println(i);
        }

    }
}

public class UsingFunctionalInterfaces {
    public static void prejava8FunctionalInterfaces(){
        Runnable target=
                () -> {
                    for(int i=1;i<=5;i++){
                        System.out.println(i);
                    }
                };

        Thread t = new Thread(target);
        t.start();
    }
    public static void java8FuncInterfaces(){

        Predicate<Integer> testAge =
                (age) -> age>50;  // test method is here

        System.out.println("Is he eligible:=" +testAge.test(56));

        List<String> names =Arrays.asList("Ramky","shyam","mani");

        Consumer<String> consumer = (arg) -> {

            String value = arg.substring(3);
            System.out.println(value);
        };

        names.forEach(consumer);
           names.forEach(System.out::println);





    }
    public static void main(String[] args) {

        //  prejava8FunctionalInterfaces();

        java8FuncInterfaces();
    }

}
