package com.training.com.training.streams;

import com.training.model.Employee;

import java.util.*;
import java.util.stream.Collectors;



public class UsingStreams {

    public static Optional<String>  getGrade(int mark){

        Optional<String> response = Optional.empty();

          if(mark>90){
              response=Optional.of("A");
          }
        return response;
    }
    public static void main(String[] args) {
        List<Employee> employeeList =
                new ArrayList<>();

        employeeList.add(new Employee(101,"Ramesh",56000));
        employeeList.add(new Employee(102,"Anand",76000));
        employeeList.add(new Employee(103,"Magesh",36000));
        employeeList.add(new Employee(104,"Zahir",86000));


        employeeList.stream().filter(employee -> employee.getSalary()>60000).forEach(System.out::println);

       List<String> nameList = employeeList.stream().filter(employee -> employee.getSalary()>60000)
                 .map(employee -> employee.getEmployeeName())
                .collect(Collectors.toList());

           nameList.forEach(System.out::println);



          Map<String,Double> map= employeeList.stream().filter(employee -> employee.getSalary()<60000)
                    .collect(Collectors.toMap(Employee::getEmployeeName,Employee::getSalary));

            map.forEach((key,value) -> System.out.println(key+","+value));

        Comparator<Employee> salcom = Comparator.comparing(Employee::getSalary);

        Optional<Employee> maxValue= employeeList.stream().max(salcom);

         if(maxValue.isPresent()){
             System.out.println(maxValue.get().getSalary());
         } else {
             System.out.println("Value not present");
         }


          Optional<String> resp=  getGrade(78);

           if(resp.isPresent()){
               System.out.println(resp.get());

           }else {
               System.out.println("Please enter a different value");
           }
    }
}
